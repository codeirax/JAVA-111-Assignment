package com.masai;

public interface Intr {
	int x =100; //public static final
	void funX(); // public abstract
	void funY();
	
	
	
	
}
