package com.masai;

public class A implements Intr{

	
 	
	public void funZ() {
		System.out.println("inside funZ of B");
		
	}

	@Override
	public void funX() {
		System.out.println("inside funX of A");
		
	}

	@Override
	public void funY() {
		System.out.println("inside funY of A");
	}
 	
	
	
}

