package com.masai;
							
public interface X extends Intr{
	
	void funA();


}
							
							