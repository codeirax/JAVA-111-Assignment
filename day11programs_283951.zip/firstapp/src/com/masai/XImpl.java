package com.masai;

public class XImpl implements X{

	@Override
	public void funX() {
		System.out.println("inside funX of XImpl");
		
	}

	@Override
	public void funY() {
		System.out.println("inside funY of XImpl");
		
	}

	@Override
	public void funA() {
		System.out.println("inside funA of XImpl");
	}

}
