package com.masai.intrp1;

public class RoadSideHotel implements Hotel {

	@Override
	public void chickenBiryani() {
		System.out.println("chicken biryani from Road Side Hotel");
		
	}

	@Override
	public void masalaDosa() {
		System.out.println("Masala Dosa from Road Side Hotel");
	}
	
	
	static void drinkingWater() {
		
		System.out.println("Drinking water from Hotel");
	}

}
