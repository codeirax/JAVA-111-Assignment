package com.masai.intrp1;

public class TajHotel implements Hotel{

	@Override
	public void chickenBiryani() {
		System.out.println("chicken biryani from Taj Hotel");
		
	}

	@Override
	public void masalaDosa() {
		System.out.println("masala Dosa from Taj Hotel");
	}
	
	public void butterRoti() {
		System.out.println("Butter Roti from Taj Hotel");
	}
	
	@Override
	public void welcomeDrink() {
		System.out.println("Welcome drink from Taj Hotel");
	}
	
	

}
