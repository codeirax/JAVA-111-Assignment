package com.masai;

class  Demo {

	
	
	
	public static void main(String[] args) {
		
		A a1 = new A();
		Intr i1 = new A();

		i1.funX();
		i1.funY();
	}
	
	
	
}


